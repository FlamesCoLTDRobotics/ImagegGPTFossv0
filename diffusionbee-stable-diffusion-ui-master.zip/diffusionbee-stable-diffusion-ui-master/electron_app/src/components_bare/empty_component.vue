<template>
</template>
<script>
export default {
    name: 'EmptyComponent',
    props: {},
    components: {},
    mounted() {

    },
    data() {
        return {};
    },
    methods: {

    },
}
</script>
<style>
</style>
<style scoped>
</style>