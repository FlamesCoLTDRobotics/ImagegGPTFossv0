# Diffusion Bee Electron App

## Project setup
```
npm install

```

### Compiles and hot-reloads for development
```
 npm run electron:serve # run via electron 
```

### Compiles and minifies for production
```
npm run electron:build
```

for building for production set env  `APPLE_ID` and `APPLE_ID_PASSWORD` 

