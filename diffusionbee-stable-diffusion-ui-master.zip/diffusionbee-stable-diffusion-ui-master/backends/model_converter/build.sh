pyinstaller  convert_model.py    --noconfirm --clean
